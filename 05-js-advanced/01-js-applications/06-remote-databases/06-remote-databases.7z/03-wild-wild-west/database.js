const database = (function () {
    // Some of these functions appear unnecessarily async
    // because otherwise synchronization issues appear between functions like deletePlayer() and loadAllPlayers(),
    // wherein it refreshes before the player is actually deleted. The solution is to await a response,
    // therefore making sure that the action has been taken before refreshing
    async function createPlayer(name) {
        const playerData = {
            name,
            money: 500,
            bullets: 6
        };

        await fetch(`${api}.json`, {
            method: 'POST',
            body: JSON.stringify(playerData)
        });
    }

    async function getAllPlayers() {
        const response = await fetch(`${api}.json`);
        const players = await response.json();

        return players;
    }

    async function updatePlayer(playerData, id) {
        await fetch(`${api}/${id}.json`, {
            method: 'PUT',
            body: JSON.stringify(playerData)
        });
    }

    async function deletePlayer(id) {
        await fetch(`${api}/${id}.json`, {
            method: 'DELETE'
        });
    }

    const api = 'https://wild-wild-west-252b8.firebaseio.com/players';

    return {
        createPlayer,
        getAllPlayers,
        updatePlayer,
        deletePlayer
    }
})();