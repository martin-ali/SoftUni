# Notes

- In problem 1, tags are, in fact saved as an array, not a single string. Modifying them in bulk is easier that way, so I put them in a single HTML element
- Used Firebase instead of Kinvey for problem 2 - [In this lecture, at this point](https://youtu.be/VkFKkuiVyOw?t=6964), it was said to use Firebase instead, so I did
- Some HTML and CSS was modified, so please don't use your own when testing
- Have a great day and stay healthy :)